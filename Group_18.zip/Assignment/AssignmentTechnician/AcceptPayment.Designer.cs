﻿namespace Assigmnet
{
    partial class frmAcceptPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblRequested = new System.Windows.Forms.Label();
            this.lblFullname = new System.Windows.Forms.Label();
            this.lblPayment = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblService = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpOnline = new System.Windows.Forms.GroupBox();
            this.radAmbank = new System.Windows.Forms.RadioButton();
            this.radCIMB = new System.Windows.Forms.RadioButton();
            this.radMaybank = new System.Windows.Forms.RadioButton();
            this.radCash = new System.Windows.Forms.RadioButton();
            this.radTngo = new System.Windows.Forms.RadioButton();
            this.radCard = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.txtOrderID = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.grpOnline.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBack.Location = new System.Drawing.Point(55, 688);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(150, 46);
            this.btnBack.TabIndex = 25;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNext.Location = new System.Drawing.Point(815, 688);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(150, 46);
            this.btnNext.TabIndex = 24;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblPrice
            // 
            this.lblPrice.BackColor = System.Drawing.Color.GhostWhite;
            this.lblPrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPrice.Location = new System.Drawing.Point(422, 355);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(241, 32);
            this.lblPrice.TabIndex = 22;
            this.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRequested
            // 
            this.lblRequested.BackColor = System.Drawing.Color.GhostWhite;
            this.lblRequested.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRequested.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRequested.Location = new System.Drawing.Point(422, 275);
            this.lblRequested.Name = "lblRequested";
            this.lblRequested.Size = new System.Drawing.Size(394, 47);
            this.lblRequested.TabIndex = 21;
            this.lblRequested.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFullname
            // 
            this.lblFullname.BackColor = System.Drawing.Color.GhostWhite;
            this.lblFullname.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFullname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblFullname.Location = new System.Drawing.Point(422, 189);
            this.lblFullname.Name = "lblFullname";
            this.lblFullname.Size = new System.Drawing.Size(241, 43);
            this.lblFullname.TabIndex = 20;
            this.lblFullname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPayment
            // 
            this.lblPayment.AutoSize = true;
            this.lblPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPayment.Location = new System.Drawing.Point(116, 428);
            this.lblPayment.Name = "lblPayment";
            this.lblPayment.Size = new System.Drawing.Size(214, 29);
            this.lblPayment.TabIndex = 18;
            this.lblPayment.Text = "Payment Method:";
            this.lblPayment.Click += new System.EventHandler(this.label6_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTotal.Location = new System.Drawing.Point(170, 358);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(148, 29);
            this.lblTotal.TabIndex = 17;
            this.lblTotal.Text = "Total Price:";
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblService.Location = new System.Drawing.Point(85, 284);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(242, 29);
            this.lblService.TabIndex = 16;
            this.lblService.Text = "Service Requested:";
            this.lblService.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblName.Location = new System.Drawing.Point(99, 196);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(226, 29);
            this.lblName.TabIndex = 15;
            this.lblName.Text = "Customer\'s Name:";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.lblTitle.Location = new System.Drawing.Point(352, 41);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(319, 38);
            this.lblTitle.TabIndex = 13;
            this.lblTitle.Text = "Payment Method";
            this.lblTitle.Click += new System.EventHandler(this.label1_Click);
            // 
            // grpOnline
            // 
            this.grpOnline.BackColor = System.Drawing.Color.GhostWhite;
            this.grpOnline.Controls.Add(this.radAmbank);
            this.grpOnline.Controls.Add(this.radCIMB);
            this.grpOnline.Controls.Add(this.radMaybank);
            this.grpOnline.Controls.Add(this.radTngo);
            this.grpOnline.Controls.Add(this.radCard);
            this.grpOnline.Controls.Add(this.radCash);
            this.grpOnline.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.grpOnline.Location = new System.Drawing.Point(376, 428);
            this.grpOnline.Name = "grpOnline";
            this.grpOnline.Size = new System.Drawing.Size(545, 238);
            this.grpOnline.TabIndex = 26;
            this.grpOnline.TabStop = false;
            this.grpOnline.Text = "Online Banking";
            this.grpOnline.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // radAmbank
            // 
            this.radAmbank.AutoSize = true;
            this.radAmbank.Location = new System.Drawing.Point(59, 167);
            this.radAmbank.Name = "radAmbank";
            this.radAmbank.Size = new System.Drawing.Size(133, 36);
            this.radAmbank.TabIndex = 31;
            this.radAmbank.TabStop = true;
            this.radAmbank.Text = "AmBank";
            this.radAmbank.UseVisualStyleBackColor = true;
            // 
            // radCIMB
            // 
            this.radCIMB.AutoSize = true;
            this.radCIMB.Location = new System.Drawing.Point(59, 114);
            this.radCIMB.Name = "radCIMB";
            this.radCIMB.Size = new System.Drawing.Size(162, 36);
            this.radCIMB.TabIndex = 29;
            this.radCIMB.TabStop = true;
            this.radCIMB.Text = "CIMBClicks";
            this.radCIMB.UseVisualStyleBackColor = true;
            // 
            // radMaybank
            // 
            this.radMaybank.AutoSize = true;
            this.radMaybank.Location = new System.Drawing.Point(59, 54);
            this.radMaybank.Name = "radMaybank";
            this.radMaybank.Size = new System.Drawing.Size(172, 36);
            this.radMaybank.TabIndex = 28;
            this.radMaybank.TabStop = true;
            this.radMaybank.Text = "Maybank2U";
            this.radMaybank.UseVisualStyleBackColor = true;
            // 
            // radCash
            // 
            this.radCash.AutoSize = true;
            this.radCash.Location = new System.Drawing.Point(327, 54);
            this.radCash.Name = "radCash";
            this.radCash.Size = new System.Drawing.Size(96, 36);
            this.radCash.TabIndex = 27;
            this.radCash.TabStop = true;
            this.radCash.Text = "Cash";
            this.radCash.UseVisualStyleBackColor = true;
            // 
            // radTngo
            // 
            this.radTngo.AutoSize = true;
            this.radTngo.Location = new System.Drawing.Point(327, 167);
            this.radTngo.Name = "radTngo";
            this.radTngo.Size = new System.Drawing.Size(104, 36);
            this.radTngo.TabIndex = 28;
            this.radTngo.TabStop = true;
            this.radTngo.Text = "TnGO";
            this.radTngo.UseVisualStyleBackColor = true;
            // 
            // radCard
            // 
            this.radCard.AutoSize = true;
            this.radCard.Location = new System.Drawing.Point(327, 114);
            this.radCard.Name = "radCard";
            this.radCard.Size = new System.Drawing.Size(165, 36);
            this.radCard.TabIndex = 29;
            this.radCard.TabStop = true;
            this.radCard.Text = "Credit Card";
            this.radCard.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.label1.Location = new System.Drawing.Point(214, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 32);
            this.label1.TabIndex = 30;
            this.label1.Text = "OrderID";
            // 
            // txtOrderID
            // 
            this.txtOrderID.Location = new System.Drawing.Point(422, 121);
            this.txtOrderID.Name = "txtOrderID";
            this.txtOrderID.Size = new System.Drawing.Size(241, 39);
            this.txtOrderID.TabIndex = 31;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSearch.Location = new System.Drawing.Point(728, 117);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(150, 46);
            this.btnSearch.TabIndex = 32;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // frmAcceptPayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(993, 758);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtOrderID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grpOnline);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblRequested);
            this.Controls.Add(this.lblFullname);
            this.Controls.Add(this.lblPayment);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblService);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblTitle);
            this.Name = "frmAcceptPayment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Laptop Repair Services Management System ";
            this.Load += new System.EventHandler(this.frmAcceptPayment_Load);
            this.grpOnline.ResumeLayout(false);
            this.grpOnline.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnBack;
        private Button btnNext;
        private Label lblPrice;
        private Label lblRequested;
        private Label lblFullname;
        private Label lblPayment;
        private Label lblTotal;
        private Label lblService;
        private Label lblName;
        private Label lblTitle;
        private GroupBox grpOnline;
        private RadioButton radAmbank;
        private RadioButton radCIMB;
        private RadioButton radMaybank;
        private RadioButton radCash;
        private RadioButton radTngo;
        private RadioButton radCard;
        private Label label1;
        private TextBox txtOrderID;
        private Button btnSearch;
    }
}