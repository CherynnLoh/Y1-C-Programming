﻿using AssignmentTechnician;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assigmnet
{
    public partial class frmAcceptPayment : Form
    {
        private string paymentmethod;
        public frmAcceptPayment()
        {
            InitializeComponent();
        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string stat;
            Service obj1 = new Service(txtOrderID.Text);
            stat = obj1.searchOrderID(txtOrderID.Text);
            if (stat == null)
            {
                Service.acceptpayview(obj1);
                lblFullname.Text = obj1.FullName;
                lblRequested.Text = obj1.Cusservice;
                lblPrice.Text = obj1.Amount.ToString();
            }
            else
                MessageBox.Show(stat);

        }

        private void frmAcceptPayment_Load(object sender, EventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (radCash.Checked == true)
               paymentmethod = radCash.Text;
            else if (radCard.Checked == true)
                paymentmethod = radCard.Text;
            else if (radTngo.Checked == true)
                paymentmethod = radTngo.Text;
            else if (radAmbank.Checked == true)
                paymentmethod=radAmbank.Text;
            else if(radMaybank.Checked == true)
                paymentmethod= radMaybank.Text;
            else if (radCIMB.Checked == true)
                paymentmethod=radCIMB.Text;

            Service obj1 = new Service(txtOrderID.Text);
            MessageBox.Show(obj1.acceptPayment(paymentmethod));
            PaymentReceipt pr = new PaymentReceipt(txtOrderID.Text);
            pr.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
