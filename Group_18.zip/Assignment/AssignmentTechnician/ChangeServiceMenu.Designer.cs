﻿namespace IoopAssignment
{
    partial class frmChangeServiceMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lstMenu = new System.Windows.Forms.ListBox();
            this.lblSelected = new System.Windows.Forms.Label();
            this.lblSelect = new System.Windows.Forms.Label();
            this.lblService = new System.Windows.Forms.Label();
            this.cmbServices = new System.Windows.Forms.ComboBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.lblTitle.Location = new System.Drawing.Point(252, 38);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(197, 28);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "Services Menu";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblTitle.Click += new System.EventHandler(this.lblTitle_Click);
            // 
            // lstMenu
            // 
            this.lstMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lstMenu.FormattingEnabled = true;
            this.lstMenu.ItemHeight = 20;
            this.lstMenu.Items.AddRange(new object[] {
            "\tService Type\t\t\tNormal\t\tUrgent",
            "",
            "1. Remove virus, malware or spyware\t\t RM 50\t\t RM 80",
            "",
            "2. Troubleshoot and fix computer running slow \t RM 60\t\t RM 90 ",
            "",
            "3. Laptop screen replacement\t\t\tRM 380\t\tRM 430",
            "",
            "4. Laptop keyboard replacement\t\tRM 160\t\tRM 200",
            "",
            "5. Laptop battery replacement\t\t\tRM 180 \t\tRM 210",
            "",
            "6. Operating System format and installation\tRM 100\t\tRM 150",
            "",
            "7. Data backup and recovery\t\t\t RM 80\t\tRM 130",
            "",
            "8. Internet connectivity issues\t\t\t RM 70\t\tRM 100"});
            this.lstMenu.Location = new System.Drawing.Point(57, 79);
            this.lstMenu.Name = "lstMenu";
            this.lstMenu.Size = new System.Drawing.Size(597, 324);
            this.lstMenu.TabIndex = 3;
            this.lstMenu.SelectedIndexChanged += new System.EventHandler(this.lstMenu_SelectedIndexChanged);
            // 
            // lblSelected
            // 
            this.lblSelected.AutoSize = true;
            this.lblSelected.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSelected.Location = new System.Drawing.Point(58, 418);
            this.lblSelected.Name = "lblSelected";
            this.lblSelected.Size = new System.Drawing.Size(145, 20);
            this.lblSelected.TabIndex = 4;
            this.lblSelected.Text = "Service Selected: ";
            this.lblSelected.Click += new System.EventHandler(this.lblUsername_Click);
            // 
            // lblSelect
            // 
            this.lblSelect.AutoSize = true;
            this.lblSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSelect.Location = new System.Drawing.Point(57, 457);
            this.lblSelect.Name = "lblSelect";
            this.lblSelect.Size = new System.Drawing.Size(174, 20);
            this.lblSelect.TabIndex = 5;
            this.lblSelect.Text = "Select a new service: ";
            this.lblSelect.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.BackColor = System.Drawing.Color.GhostWhite;
            this.lblService.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblService.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblService.Location = new System.Drawing.Point(225, 418);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(2, 22);
            this.lblService.TabIndex = 6;
            this.lblService.Click += new System.EventHandler(this.lblService_Click);
            // 
            // cmbServices
            // 
            this.cmbServices.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cmbServices.FormattingEnabled = true;
            this.cmbServices.Items.AddRange(new object[] {
            "Remove virus, malware or spyware",
            "Remove virus, malware or spyware (Urgent)",
            "Troubleshoot and fix computer running slow",
            "Troubleshoot and fix computer running slow (Urgent)",
            "Laptop screen replacement",
            "Laptop screen replacement (Urgent)",
            "Laptop keyboard replacement",
            "Laptop keyboard replacement (Urgent)",
            "Laptop battery replacement",
            "Laptop battery replacement (Urgent)",
            "Operating System format and installation",
            "Operating System format and installation (Urgent)",
            "Data backup and recovery",
            "Data backup and recovery (Urgent)",
            "Internet connectivity issues",
            "Internet connectivity issues (Urgent)"});
            this.cmbServices.Location = new System.Drawing.Point(225, 452);
            this.cmbServices.Name = "cmbServices";
            this.cmbServices.Size = new System.Drawing.Size(429, 28);
            this.cmbServices.TabIndex = 7;
            this.cmbServices.SelectedIndexChanged += new System.EventHandler(this.cmbServices_SelectedIndexChanged);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBack.Location = new System.Drawing.Point(12, 495);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(106, 26);
            this.btnBack.TabIndex = 10;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnConfirm.Location = new System.Drawing.Point(594, 495);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(106, 26);
            this.btnConfirm.TabIndex = 11;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // frmChangeServiceMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(712, 533);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.cmbServices);
            this.Controls.Add(this.lblService);
            this.Controls.Add(this.lblSelect);
            this.Controls.Add(this.lblSelected);
            this.Controls.Add(this.lstMenu);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "frmChangeServiceMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Laptop Repair Services Management System";
            this.Load += new System.EventHandler(this.frmChangeServiceMenu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private ListBox lstMenu;
        private Label lblSelected;
        private Label lblSelect;
        private Label lblService;
        private ComboBox cmbServices;
        private Button btnBack;
        private Button btnConfirm;
    }
}