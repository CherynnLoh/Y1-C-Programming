﻿using AssignmentTechnician;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IoopAssignment
{
    public partial class frmChangeServiceMenu : Form
    {
        public static string name;
        public string service;
        public int price;

        public frmChangeServiceMenu()
        {
            InitializeComponent();
        }

        public frmChangeServiceMenu(string n)
        {
            InitializeComponent();
            name = n;
        }

        private void lblUsername_Click(object sender, EventArgs e)
        {

        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void frmChangeServiceMenu_Load(object sender, EventArgs e)
        {
            //available then show the service selected in the order
            Service obj1 = new Service(name);
            Service.viewServiceselected(obj1);
            lblService.Text = obj1.Cusservice;
        }

        private void lstMenu_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblService_Click(object sender, EventArgs e)
        {

        }

        private void cmbServices_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = cmbServices.SelectedIndex;
            if (index == 0)
            {
                service = "Remove virus, malware or spyware";
                price = 50;
            }
            else if (index == 1)
            {
                service = "Remove virus, malware or spyware(Urgent)";
                price = 80;
            }
            else if (index == 2)
            {
                service = "Troubleshoot and fix computer running slow";
                price = 60;
            }
            else if (index == 3)
            {
                service = "Troubleshoot and fix computer running slow(Urgent)";
                price = 60;
            }
            else if (index == 4)
            {
                service = "Laptop screen replacement";
                price = 380;
            }
            else if (index == 5)
            {
                service = "Laptop screen replacement(Urgent)";
                price = 430;
            }
            else if (index == 6)
            {
                service = "Laptop keyboard replacement";
                price = 160;
            }
            else if (index == 7)
            {
                service = "Laptop keyboard replacement(Urgent)";
                price = 200;
            }
            else if (index == 8)
            {
                service = "Laptop battery replacement";
                price = 180;
            }
            else if (index == 9)
            {
                service = "Laptop battery replacement(Urgent)";
                price = 210;
            }
            else if (index == 10)
            {
                service = "Operating System Format and Installation";
                price = 100;
            }
            else if (index == 11)
            {
                service = "Operating System Format and Installation(Urgent)";
                price = 150;
            }
            else if (index == 12)
            {
                service = "Data backup and recovery";
                price = 80;
            }
            else if (index == 13)
            {
                service = "Data backup and recovery(Urgent)";
                price = 130;
            }
            else if (index == 14)
            {
                service = "Internet connectivity issues";
                price = 70;
            }
            else if (index == 15)
            {
                service = "Internet connectivity issues(Urgent)";
                price = 100;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            //validation of combobox
            if (cmbServices.SelectedIndex >= 0)
            {
                Service obj1 = new Service(name);
                
                //old != new service, only can proceed to updateService method
                if (service != lblService.Text)
                {
                    MessageBox.Show(obj1.updateService(service,price)); //parameter=newservice
                    lblService.Text = service;
                }
                else
                    MessageBox.Show("No changes made.");
            }
            else
                MessageBox.Show("Choose a new service you want.");
        }
    }
}
