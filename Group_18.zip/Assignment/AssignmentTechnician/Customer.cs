﻿using Assigmnet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AssignmentTechnician
{
    internal class Customer
    {
        private string username;
        private string cusfullName;
        private string password;
        private string cusName;
        private string cusEmail;
        private string cusPhone;
        private string cusGender;
        private string confpass;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public string CusEmail { get => cusEmail; set => cusEmail = value; }
        public string CusPhone { get => cusPhone; set => cusPhone = value; }
        public string CusfullName { get => cusfullName; set => cusfullName = value; }
        public string CusGender { get => cusGender; set => cusGender = value; }

        public Customer(string u, string p, string c, string e, string n, string g)
        {
            username = u;
            password = p;
            cusName = c;
            cusEmail = e;
            cusPhone = n;
            cusGender = g;
        }

        public Customer(string n)
        {
            username = n;
        }

        /*NewCustomer Form: Insert into Customer Table*/
        public string AddCustomer(string un,string conpass)
        {
            string status = null;
            confpass = conpass;
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Customer(CusUsername,CusFullName,Email,ContactNum,Gender) values(@username,@name,@em,@num,@gender)", con);
            SqlCommand cmd3 = new SqlCommand("insert into users(username,password,role) values (@username,@pass,'customer')", con);
            SqlCommand cmd2 = new SqlCommand("select count(*) from users where username ='" + username + "'", con);
            SqlCommand cmd4 = new SqlCommand("select count(*) from Customer where ContactNum ='" + cusPhone + "'", con);
            SqlCommand cmd5 = new SqlCommand("select count(*) from Staff where ContactNum ='" + cusPhone + "'", con);
            SqlCommand cmd6 = new SqlCommand("select count(*) from Customer where Email ='" + cusEmail + "'", con);
            SqlCommand cmd7 = new SqlCommand("select count(*) from Staff where Email ='" + cusEmail + "'", con);
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@name", cusName);
            cmd.Parameters.AddWithValue("@em", cusEmail);
            cmd.Parameters.AddWithValue("@num", cusPhone);
            cmd.Parameters.AddWithValue("@gender", cusGender);
            cmd3.Parameters.AddWithValue("@username", username);
            cmd3.Parameters.AddWithValue("@pass", password);

            int count = Convert.ToInt32(cmd2.ExecuteScalar());
            int checkPhCus = Convert.ToInt32(cmd4.ExecuteScalar());
            int checkPhStaff = Convert.ToInt32(cmd5.ExecuteScalar());
            int checkEmailCus = Convert.ToInt32(cmd6.ExecuteScalar());
            int checkEmailStaff = Convert.ToInt32(cmd7.ExecuteScalar());

            Regex hasNumber = new Regex(@"[0-9]+");
            Regex hasUpperChar = new Regex(@"[A-Z]+");
            Regex hasMinimum12Chars = new Regex(@".{12,}");
            Regex hasLowerChar = new Regex(@"[a-z]+");
            Regex hasSymbols = new Regex(@"[!@#$%^&*()_+=\[{\]};:<>|./?,-]");
            Regex emailformat = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Regex phoneformat = new Regex(@"^\(?([0-9]{3})\)?-([0-9]{7})$");
            bool isValidated = hasNumber.IsMatch(password) && hasUpperChar.IsMatch(password) && hasMinimum12Chars.IsMatch(password) && hasLowerChar.IsMatch(password) && hasSymbols.IsMatch(password);

            if (count > 0)
            {
                MessageBox.Show("Username already exists!");
                status = "Registration Unuccessful!";
            }
            else if ((checkPhCus > 0) || (checkPhStaff > 0))
            {
                MessageBox.Show("Phone Number already exist!");
                status = " Registration Unucccessful!";
            }
            else if ((checkEmailCus > 0) || (checkEmailStaff > 0))
            {
                MessageBox.Show("Email already exist!");
                status = " Registration Unucccessful!";
            }
            else if (!emailformat.IsMatch(cusEmail))
            {
                MessageBox.Show("Email Format Incorrect!" + "\n" + "Format : xxx@xxx.com");
                status = " Registration Unucccessful!";
            }
            else if (!phoneformat.IsMatch(cusPhone))
            {
                MessageBox.Show("Contact Number Format Incorrect!" + "\n" + "Format: 000-0000000 (Only Integers Allowed)");
                status = " Registration Unucccessful!";
            }
            else if (isValidated == false)
            {
                MessageBox.Show("Password must contain at least a number, one upper case letter,one lower case letter ,one symbol(min12 characters");
                status = " Registration Unucccessful!";
            }
            else if (confpass != password)
            {
                MessageBox.Show("Password does not match");
                status = " Registration Unucccessful!";
            }
            else
            {
                cmd3.ExecuteNonQuery();
                cmd.ExecuteNonQuery();
                status = "Registration Succesful";
                frmService r = new frmService(un);
                OrderConfirm oc = new OrderConfirm(un);
                r.ShowDialog();

            }
            con.Close();
            return status;
        }
        //frmUpdateProfile(step1) loaded
        public static void viewProfile(Customer o1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Customer where CusUsername = '" + o1.username + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                o1.cusfullName = rd.GetString(2);
                o1.cusEmail = rd.GetString(3);
                o1.cusPhone = rd.GetString(4);
                o1.cusGender = rd.GetString(5);
            }
            con.Close();
        }

        //frmUpdateProfile(step2) edit email button clicked
        public string updateCusEmail(string em)
        {
            string status;
            con.Open();
            cusEmail = em;
            SqlCommand cmd1 = new SqlCommand("select count(*) from Customer where Email ='" + cusEmail + "'", con);
            SqlCommand cmd2 = new SqlCommand("update Customer set Email ='" + cusEmail + "'where CusUsername ='" + username + "'", con);
            int checkEmailCus = Convert.ToInt32(cmd1.ExecuteScalar());

            if ((checkEmailCus > 0))
            {
                status = "Update Failed\nThis email has existed in the record.";
            }
            else
            {
                int i = cmd2.ExecuteNonQuery();
                if (i != 0)
                    status = "Update Successfully";
                else
                    status = "Unable to update.";
            }
            con.Close();
            return status;
        }

        //frmUpdateProfile(step2) edit phone number button clicked
        public string updateCusPhone(string num)
        {
            string status;
            con.Open();
            cusPhone = num;
            SqlCommand cmd1 = new SqlCommand("select count(*) from Customer where ContactNum ='" + cusPhone + "'", con);
            SqlCommand cmd2 = new SqlCommand("update Customer set ContactNum ='" + cusPhone + "'where CusUsername ='" + username + "'", con);
            int checkNumCus = Convert.ToInt32(cmd1.ExecuteScalar());

            if ((checkNumCus > 0))
            {
                status = "Update Failed\nThis contact number has existed in the record.";
            }
            else
            {
                int i = cmd2.ExecuteNonQuery();
                if (i != 0)
                    status = "Update Successfully";
                else
                    status = "Unable to update.";
            }
            con.Close();
            return status;
        }

    }
}
