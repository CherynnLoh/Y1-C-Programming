﻿using AssignmentTechnician;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IoopAssignment
{
    public partial class frmCustomerMenu : Form
    {
        public static string name;
        public static string password; 

        public frmCustomerMenu()
        {
            InitializeComponent();
        }

        public frmCustomerMenu(string n,string pw)
        {
            InitializeComponent();
            name = n;
            password = pw;
        }

        private void frmCustomerMenu_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = "Welcome, " + name;
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            //to search is there orderid to change service
            Service obj1 = new Service(name);
            string status = obj1.checkOrderID();

            //unavailable then won't open form
            if (status != null)
            {
                MessageBox.Show(status);
            }
            else
            {
                frmChangeServiceMenu chg = new frmChangeServiceMenu(name);
                chg.ShowDialog();
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            frmViewServiceRequested v = new frmViewServiceRequested(name);
            v.ShowDialog();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            frmUpdateProfile u = new frmUpdateProfile(name,password); 
            u.ShowDialog();
        }
        private void grpOption_Enter(object sender, EventArgs e)
        {
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
