﻿using AssignmentTechnician;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPFORM
{
    public partial class Income : Form
    {
        public static string YearRPT;
        public static string MonthRPT;
        
        public Income()
        {
            InitializeComponent();
        }

        private void lstReport_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            YearRPT = cmbYear.GetItemText(cmbYear.SelectedItem);
            MonthRPT = cmbMonth.GetItemText(cmbMonth.SelectedItem);

            int MonthNumber = GetMonthNumber_From_MonthName(MonthRPT);
            if (MonthNumber < 10)
            {
                ArrayList name = new ArrayList();
                //call static method --> className.method(..)
                Service obj3 = new Service(YearRPT + "-0" + MonthNumber);
                lstReport.Items.Clear();
                lstReport.Items.Add("Order          Date                  Service Fee");
                name = Service.viewIncome(obj3);
                foreach (var item in name)
                {
                    lstReport.Items.Add(item);
                }
                ArrayList income = new ArrayList();
                income = Service.ViewTotalIncome(obj3);
                lblIncome.Text = " Total Income of the Month:  RM" + income[0].ToString() + "  Income";

            }

            else
            {
                ArrayList name = new ArrayList();
                //call static method --> className.method(..)
                Service obj3 = new Service(YearRPT + "-" + MonthNumber);
                lstReport.Items.Clear();
                lstReport.Items.Add("Order          Date                  Service Fee");
                name = Service.viewIncome(obj3);
                foreach (var item in name)
                {
                    lstReport.Items.Add(item);
                }
                int countlst = lstReport.Items.Count - 1;

                ArrayList income = new ArrayList();
                income = Service.ViewTotalIncome(obj3);
                lblIncome.Text = " Total Income of the Month:  RM" + income[0].ToString() + "  Income";
            }
        }
        public static int GetMonthNumber_From_MonthName(string monthname)
        {
            int monthNumber = 0;
            monthNumber = DateTime.ParseExact(monthname, "MMMM", CultureInfo.CurrentCulture).Month;
            return monthNumber;
        }

        private void Income_Load(object sender, EventArgs e)
        {

        }
    }
}
