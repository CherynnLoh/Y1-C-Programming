﻿namespace IOOPFORM
{
    partial class Menu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.grpOption = new System.Windows.Forms.GroupBox();
            this.btnIncome = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.btnNewReceptionist = new System.Windows.Forms.Button();
            this.btnNewTechnician = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.grpOption.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.lblTitle.Location = new System.Drawing.Point(268, 90);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(193, 28);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Admin\'s Menu";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(202, 204);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 23);
            this.label2.TabIndex = 1;
            // 
            // grpOption
            // 
            this.grpOption.Controls.Add(this.btnIncome);
            this.grpOption.Controls.Add(this.btnReport);
            this.grpOption.Controls.Add(this.btnNewReceptionist);
            this.grpOption.Controls.Add(this.btnNewTechnician);
            this.grpOption.Location = new System.Drawing.Point(173, 166);
            this.grpOption.Name = "grpOption";
            this.grpOption.Size = new System.Drawing.Size(379, 291);
            this.grpOption.TabIndex = 2;
            this.grpOption.TabStop = false;
            this.grpOption.Text = "Select an Option";
            // 
            // btnIncome
            // 
            this.btnIncome.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnIncome.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIncome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnIncome.Location = new System.Drawing.Point(75, 222);
            this.btnIncome.Name = "btnIncome";
            this.btnIncome.Size = new System.Drawing.Size(242, 49);
            this.btnIncome.TabIndex = 3;
            this.btnIncome.Text = "View Total Income (Monthly)";
            this.btnIncome.UseVisualStyleBackColor = false;
            this.btnIncome.Click += new System.EventHandler(this.btnIncome_Click);
            // 
            // btnReport
            // 
            this.btnReport.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnReport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnReport.Location = new System.Drawing.Point(75, 166);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(242, 49);
            this.btnReport.TabIndex = 2;
            this.btnReport.Text = "View Service Report (Monthly)";
            this.btnReport.UseVisualStyleBackColor = false;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // btnNewReceptionist
            // 
            this.btnNewReceptionist.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnNewReceptionist.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNewReceptionist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNewReceptionist.Location = new System.Drawing.Point(75, 109);
            this.btnNewReceptionist.Name = "btnNewReceptionist";
            this.btnNewReceptionist.Size = new System.Drawing.Size(242, 49);
            this.btnNewReceptionist.TabIndex = 1;
            this.btnNewReceptionist.Text = "Register New Receptionist";
            this.btnNewReceptionist.UseVisualStyleBackColor = false;
            this.btnNewReceptionist.Click += new System.EventHandler(this.btnNewReceptionist_Click);
            // 
            // btnNewTechnician
            // 
            this.btnNewTechnician.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnNewTechnician.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNewTechnician.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNewTechnician.Location = new System.Drawing.Point(75, 53);
            this.btnNewTechnician.Name = "btnNewTechnician";
            this.btnNewTechnician.Size = new System.Drawing.Size(242, 49);
            this.btnNewTechnician.TabIndex = 0;
            this.btnNewTechnician.Text = "Register New Technician";
            this.btnNewTechnician.UseVisualStyleBackColor = false;
            this.btnNewTechnician.Click += new System.EventHandler(this.btnNewTechnician_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnLogout.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLogout.Location = new System.Drawing.Point(542, 493);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(145, 31);
            this.btnLogout.TabIndex = 4;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(795, 554);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.grpOption);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblTitle);
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Laptop Repair Services Management System";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.grpOption.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private Label label2;
        private GroupBox grpOption;
        private Button btnIncome;
        private Button btnReport;
        private Button btnNewReceptionist;
        private Button btnNewTechnician;
        private Button btnLogout;
    }
}