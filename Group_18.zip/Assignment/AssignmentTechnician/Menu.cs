namespace IOOPFORM
{
    public partial class Menu : Form
    {
        public Menu(string un)
        {
            InitializeComponent();
            
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            btnLogout.FlatAppearance.BorderColor = Color.MediumVioletRed;
            this.Close();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void btnNewTechnician_Click(object sender, EventArgs e)
        {
            
            Form New_Technician = new New_Technician();
            New_Technician.ShowDialog();
            
        }

        private void btnNewReceptionist_Click(object sender, EventArgs e)
        {
            
            Form New_Receptions = new New_Receptions();
            New_Receptions.ShowDialog();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            
            Form Report= new Report();
            Report.ShowDialog();
        }

        private void btnIncome_Click(object sender, EventArgs e)
        {
            
            Form Income = new Income();
            Income.ShowDialog();
        }
    }
}