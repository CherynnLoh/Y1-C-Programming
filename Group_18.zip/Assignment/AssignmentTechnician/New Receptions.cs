﻿using AssignmentTechnician;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPFORM
{
    public partial class New_Receptions : Form
    {
        public New_Receptions()
        {
            InitializeComponent();
        }

        private void New_Receptions_Load(object sender, EventArgs e)
        {

        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text.Trim()))
            {
                errorProvider1.SetError(txtName, "Fullname is Required");
                return;
            }
            else 
            {
                errorProvider1.SetError(txtName, string.Empty);
            }
            if (string.IsNullOrEmpty(txtUsername.Text.Trim()))
            {
                errorProvider2.SetError(txtUsername, "Username is Required");
                return;
            }
            else
            {
                errorProvider2.SetError(txtUsername, string.Empty);
            }
            if (string.IsNullOrEmpty(txtEmail.Text.Trim()))
            {
                errorProvider3.SetError(txtEmail, "Email is Required with @");
                return;
            }
            else
            {
                errorProvider3.SetError(txtEmail, string.Empty);
            }
            if (string.IsNullOrEmpty(txtContact.Text.Trim()))
            {
                errorProvider4.SetError(txtContact, "Contact is Required with xxx-");
                return;
            }
            else
            {
                errorProvider4.SetError(txtContact, string.Empty);
            }
            if (string.IsNullOrEmpty(txtPassword.Text.Trim()))
            {
                errorProvider5.SetError(txtPassword, "Password is Required");
                return;
            }
            else
            {
                errorProvider5.SetError(txtPassword, string.Empty);

            }
            if (string.IsNullOrEmpty(txtConPassword.Text.Trim()))
            {
                errorProvider6.SetError(txtConPassword, "Confirm Password is Required");
                return;
            }
            else
            {
                errorProvider6.SetError(txtConPassword, string.Empty);
            }
            Regex emailformat = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = emailformat.Match(txtEmail.Text);
            Regex phoneformat = new Regex(@"^\(?([0-9]{3})\)?-([0-9]{7})$");
            Match match1 = phoneformat.Match(txtContact.Text);
            Regex hasNumber = new Regex(@"[0-9]+");
            Regex hasUpperChar = new Regex(@"[!A-Z]+");
            Regex hasMinimum12Chars = new Regex(@".{12,}");
            Regex hasLowerChar = new Regex(@"[a-z]+");
            Regex hasSymbols = new Regex(@"[!@#$%^&*()_+=\[{\]};:<>|./?,-]");
            Staff ong = new Staff(txtUsername.Text, txtName.Text, txtContact.Text, txtEmail.Text, "Female", txtConPassword.Text);
            Staff.viewProfile(ong);
            if (match.Success == false)
            {
                MessageBox.Show("Email Format(xxx@xxx.com)");
            }
            else if (match1.Success == false)
            {
                MessageBox.Show("Invalid Phone Format(xxx-xxxxxxx) 10 digits");
            }
            else if (hasNumber.IsMatch(txtPassword.Text) == false || hasMinimum12Chars.IsMatch(txtPassword.Text) == false)
            {
                MessageBox.Show("Password Requirement 12 Charactors or 1 Number");
            }
            else if (hasUpperChar.IsMatch(txtPassword.Text) == false || hasLowerChar.IsMatch(txtPassword.Text) == false || hasSymbols.IsMatch(txtPassword.Text) == false)
            {
                MessageBox.Show("Password Requirement One Uppercase/Lowercase and One Symbol");
            }
            else
            {
                //if (txtPassword.Text == txtConPassword.Text && txtUsername.Text!="" && txtName.Text != "" && txtContact.Text != "" && txtEmail.Text != "")
                if (txtPassword.Text == txtConPassword.Text)
                {
                    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
                    conn.Open();
                    SqlCommand cmd2 = new SqlCommand("select Staffusername from Staff where Staffusername=@staffusername or ContactNum=@Contactnum or Email=@email ", conn);
                    cmd2.Parameters.AddWithValue("staffusername", txtUsername.Text);
                    cmd2.Parameters.AddWithValue("Contactnum", txtContact.Text);
                    cmd2.Parameters.AddWithValue("email", txtEmail.Text);
                    SqlDataReader myreader = cmd2.ExecuteReader();
                    if (myreader.Read())
                    {
                        conn.Close();
                        MessageBox.Show("Duaplicate Username");
                    }
                    else
                    {
                        if (radFemale.Checked)
                        {
                            Staff obj1 = new Staff(txtUsername.Text, txtName.Text, txtContact.Text, txtEmail.Text, "Female", txtConPassword.Text);
                            MessageBox.Show(obj1.addReceptionist());
                        }
                        else if (radMale.Checked)
                        {
                            Staff obj1 = new Staff(txtUsername.Text, txtName.Text, txtContact.Text, txtEmail.Text, "Male", txtConPassword.Text);
                            MessageBox.Show(obj1.addReceptionist());
                        }
                        else
                        {
                            MessageBox.Show("Select Gender");
                        }
                    }

                }
                else
                {
                    MessageBox.Show("Password are not same");
                }
            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radFemale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            //this.Hide();
            //Login L = new Login();
            //L.ShowDialog();
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            
        }


    }
}
