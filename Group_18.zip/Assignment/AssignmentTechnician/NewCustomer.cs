﻿using AssignmentTechnician;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assigmnet
{
    public partial class frmNewCustomer : Form
    {
        private string gender;
        public frmNewCustomer()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

 
        private void radMale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radFemale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void frmNewCustomer_Load(object sender, EventArgs e)
        {

        }

        private void frmNewCustomer_Load_1(object sender, EventArgs e)
        {

        }

        private void btnConfirm_Click_2(object sender, EventArgs e)
        {

            if (radFemale.Checked == true)
                gender = radFemale.Text;
            else if (radMale.Checked == true)
                gender = radMale.Text;

            if (String.IsNullOrEmpty(txtUsername.Text))
            {
                MessageBox.Show("Please Enter Username");
            }

            else
            {
                Customer obj1 = new Customer(txtUsername.Text, txtPassword.Text, txtName.Text, txtEmail.Text, txtContact.Text, gender);
                MessageBox.Show(obj1.AddCustomer(txtName.Text, txtConPass.Text));

                txtName.Text = String.Empty;
                txtEmail.Text = String.Empty;
                txtContact.Text = String.Empty;
                txtUsername.Text = String.Empty;
                txtPassword.Text = String.Empty;
                txtConPass.Text = String.Empty;
            }
        }


        private void btnNext_Click(object sender, EventArgs e)
        {
            
        }

        private void radMale_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
   

