﻿using AssignmentTechnician;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assigmnet
{
    public partial class OrderConfirm : Form
    {
        private string cusfullname;
        public OrderConfirm()
        {
            InitializeComponent();
        }
        public OrderConfirm(string n)
        {
            InitializeComponent();
            cusfullname = n;

        }
        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void OrderConfirm_Load(object sender, EventArgs e)
        {
            Service obj1 = new Service(cusfullname);
            Service.viewSelected(obj1);

            lblID.Text = obj1.OrderID;
            lblName.Text = obj1.FullName;
            lblRequested.Text = obj1.Cusservice;
            lblPrice.Text = obj1.Amount.ToString();
            lblDate.Text = obj1.Orderdate;
        }

        private void lblID_Click(object sender, EventArgs e)
        {

        }

        private void lblTransaction_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
