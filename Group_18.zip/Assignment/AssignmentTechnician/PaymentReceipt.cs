﻿using AssignmentTechnician;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assigmnet
{
    public partial class PaymentReceipt : Form
    {
        string transactiondate,orderid;
        public PaymentReceipt()
        {
            InitializeComponent();
        }
        
        public PaymentReceipt(string order)
        {
            InitializeComponent();
            orderid = order;
        }

        private void PaymentReceipt_Load(object sender, EventArgs e)
        {
            transactiondate = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss");
            lblDate.Text = transactiondate;

            Service obj1 = new Service(orderid);
            Service.viewReceipt(obj1);

            lblName.Text = obj1.FullName;
            lblID.Text = obj1.OrderID;
            lblRequested.Text = obj1.Cusservice;
            lblPrice.Text = obj1.Amount.ToString();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void lblTransaction_Click(object sender, EventArgs e)
        {

        }

        private void lblOrder_Click(object sender, EventArgs e)
        {

        }

        private void lblCustomer_Click(object sender, EventArgs e)
        {

        }

        private void lblService_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
