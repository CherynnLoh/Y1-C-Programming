﻿using AssignmentTechnician;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assigmnet
{
    public partial class ReceptionistMenu : Form
    {
        public string username;
        public string password;
        public ReceptionistMenu()
        {
            InitializeComponent();
        }
        public ReceptionistMenu(string n)
        {
            InitializeComponent();
            username = n;
        }

        public ReceptionistMenu(string n,string p)
        {
            InitializeComponent();
            username = n;
            password = p;
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            frmNewCustomer add = new frmNewCustomer();
            add.ShowDialog();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            frmUpdateProfile update = new frmUpdateProfile(username,password);
            update.ShowDialog();
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            frmAcceptPayment payment = new frmAcceptPayment();
            payment.ShowDialog();
        }
        private void ReceptionistMenu_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = "Welcome " + username + "!  Role: Receptionist ";
        }

        private void lblWelcome_Click(object sender, EventArgs e)
        {
           
        }
        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
