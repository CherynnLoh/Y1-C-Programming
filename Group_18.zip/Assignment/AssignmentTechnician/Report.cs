﻿using AssignmentTechnician;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOPFORM
{
    public partial class Report : Form
    {
        public static string YearRPT;
        public static string MonthRPT;
        
        public Report()
        {
            InitializeComponent();
        }
        public Report(string yr,string mt)
        {
            InitializeComponent();
            YearRPT = yr;
            MonthRPT = mt;
        }
        private void btnCheck_Click(object sender, EventArgs e)
        {
            
            YearRPT = cmbYear.GetItemText(cmbYear.SelectedItem);
            MonthRPT = cmbMonth.GetItemText(cmbMonth.SelectedItem);
            
            int MonthNumber = GetMonthNumber_From_MonthName(MonthRPT);
            if (MonthNumber <10) 
            {
                ArrayList name = new ArrayList();
                //call static method --> className.method(..)
                Service obj2 = new Service(YearRPT + "-0" + MonthNumber);
                lstReport.Items.Clear();
                lstReport.Items.Add("Order          Date                  Service Type");
                name = Service.viewAll(obj2);
                foreach (var item in name)
                {
                    lstReport.Items.Add(item);
                }
                int countlst = lstReport.Items.Count - 1;
                
                lblOrder.Text = " Total Order of the Month:  " + countlst+" Orders";
                if (countlst == 0)
                {
                    lstReport.Items.Add("Dont Have Any Order During This Month");
                }
            }

            else
            {
                ArrayList name = new ArrayList();
                //call static method --> className.method(..)
                Service obj2 = new Service(YearRPT + "-" + MonthNumber);
                lstReport.Items.Clear();
                lstReport.Items.Add("Order          Date                  Service Type");
                name = Service.viewAll(obj2);
                foreach (var item in name)
                {
                    lstReport.Items.Add(item);
                }
                int countlst = lstReport.Items.Count - 1;

                lblOrder.Text = " Total Order of the Month:  " + countlst+"  Orders";
                if (countlst == 0)
                {
                    lstReport.Items.Add("Dont Have Any Order During This Month");
                }
            }
            

            //calling static method require className.method(..)
            //pass object obj1 to method viewProfile

            ///Service.viewProfile(obj1);

            //arraylist allows you to create dynamic size array
            
        }

        private void cmbYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            //YearRPT = this.cmbYear.GetItemText(this.cmbYear.SelectedItem);

        }

        private void cmbMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
           // MonthRPT= this.cmbMonth.GetItemText(this.cmbMonth.SelectedItem);
           

        }

        private void lstReport_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Report_Load(object sender, EventArgs e)
        {
                       
        }
        public static int GetMonthNumber_From_MonthName(string monthname)
        {
            int monthNumber = 0;
            monthNumber = DateTime.ParseExact(monthname, "MMMM", CultureInfo.CurrentCulture).Month;
            return monthNumber;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
