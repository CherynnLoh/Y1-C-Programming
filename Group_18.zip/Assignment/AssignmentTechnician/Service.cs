﻿using Assigmnet;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentTechnician
{
    internal class Service
    {
        private string orderID;
        private string userName;
        private string fullName;
        private string cusservice;
        private int amount;
        private string payment;
        private string status;
        private string description;
        private string orderdate;
        private string collectiondate;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public string FullName { get => fullName; set => fullName = value; }
        public string Cusservice { get => cusservice; set => cusservice = value; }
        public string Status { get => status; set => status = value; }
        public string Orderdate { get => orderdate; set => orderdate = value; }
        public string UserName { get => userName; set => userName = value; }
        public string Payment { get => payment; set => payment = value; }
        public string Description { get => description; set => description = value; }
        public string Collectiondate { get => collectiondate; set => collectiondate = value; }
        public int Amount { get => amount; set => amount = value; }
        public string OrderID { get => orderID; set => orderID = value; }

        public Service(string x)
        {
            userName = x;
            fullName = x;
            orderID = x;
            orderdate = x;
        }

        public static void viewService(Service o1)//recieve object of class Service
        {
            con.Open();   
            SqlCommand cmd1 = new SqlCommand("select * from service where orderID ='" + o1.orderID + "'", con);
            SqlDataReader rd = cmd1.ExecuteReader();
            while (rd.Read())
            {
                o1.orderID = rd.GetString(1);
                o1.userName = rd.GetString(2);
                o1.fullName = rd.GetString(3);
                o1.cusservice = rd.GetString(4);
                o1.amount =rd.GetInt32(5);
                //o1.payment = rd.GetString(6);
                o1.status = rd.GetString(7);
                o1.orderdate = rd.GetDateTime(8).ToShortDateString();
                if (rd.IsDBNull(6) == true)
                {
                    o1.payment = "";
                }
                else
                {
                    o1.payment = rd.GetString(6);
                }
                if (rd.IsDBNull(9) == true)
                {
                    o1.description = "";
                }
                else
                    o1.description = rd.GetString(9);
                if (rd.IsDBNull(10) == true)
                {
                    o1.collectiondate = "";
                }
                else
                    o1.collectiondate = rd.GetDateTime(10).ToShortDateString();
            }
            con.Close();
        }

        public string checkOrderID(string orderid)
        {
            string status = null;
            con.Open();
            SqlCommand cmd = new SqlCommand("select count(*) from service where orderID ='" + orderID + "'", con);
            int count = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (count > 0)
            {
                con.Close();
                return status;
            }
            else
                status = "Invalid Order ID";
                con.Close();
            return status;
        }
        
        public string updateStatus(string stat)
        {
            string status;
            con.Open();

            status = stat;
            SqlCommand cmd = new SqlCommand("update Service set Status ='"+ stat + "'"+"where OrderID ='"+ orderID+ "'", con);
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Update Successfully.";
            else
                status = "Unable to update.";
            con.Close();
            return status;
        }

        public string updateDesCollection(string stat,string desc,string collectdt)
        {
            string message;
            string status;
            string description;
            string collectionDate;

            con.Open();
            status = stat;
            description = desc;
            collectionDate = collectdt;

            if(status != "Complete")
            {
                message = "Must Enter ‘Complete’ to update！！！";
                con.Close();
                return message;
            }

            SqlCommand cmd = new SqlCommand("update Service set Status='" + status + "',Description='" + description + "',CollectionDate ='" +collectionDate+"'where OrderID ='" + orderID + "'", con);
            int i =cmd.ExecuteNonQuery();
            if(i != 0)
            {
                message = "The information Completion of Service is updated completely!";
            }
            else
            {
                message = "Unable to update,:(";
            }
            con.Close();

            return message;

            
        }
        public string SelectService(string sv, int pc)
        {

            string id, status;
            string leftside;
            int increment;
            cusservice = sv;
            amount = pc;
            //date for OrderDate
            orderdate = DateTime.Now.ToString("MM/dd/yyyy");

            //autoincrement OrderID
            con.Open();
            SqlCommand cmd3 = new SqlCommand("SELECT MAX(OrderID) FROM Service", con);
            SqlDataReader rd2 = cmd3.ExecuteReader();
            if (rd2.Read())
            {
                id = rd2[0].ToString();
                increment = int.Parse(new string(id.Where(char.IsDigit).ToArray()));
                leftside = new string(id.Where(char.IsLetter).ToArray());
                id = leftside + (increment + 1).ToString("0000");
                orderID = id;
            }
            con.Close();

            /*Insert data into Service Table*/
            con.Open();
            SqlCommand cmd2 = new SqlCommand("select * from Customer where CusFullName ='" + fullName + "'", con);
            SqlDataReader rd = cmd2.ExecuteReader();
            while (rd.Read())
            {
                userName = rd.GetString(1);
            }
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Service(OrderID,Username,FullName,Service,Amount,OrderDate) values (@orderid,@username,@name,@service,@amount,@orderdate)", con);
            cmd.Parameters.AddWithValue("@orderid", orderID);
            cmd.Parameters.AddWithValue("@username", userName);
            cmd.Parameters.AddWithValue("@name", fullName);
            cmd.Parameters.AddWithValue("@service", cusservice);
            cmd.Parameters.AddWithValue("@amount", amount);
            cmd.Parameters.AddWithValue("@orderdate", orderdate);

            int i = cmd.ExecuteNonQuery();
            if (i != 0)
            {
                status = "Service Selected: " + cusservice;

            }
            else
                status = "Update Service Failed";
            con.Close();
            return status;
        }

        /*OrderConfirm: Display */
        public static void viewSelected(Service o1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select OrderID,FullName,Service,Amount,OrderDate from Service where FullName ='" + o1.fullName + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                o1.orderID = rd.GetString(0);
                o1.fullName = rd.GetString(1);
                o1.cusservice = rd.GetString(2);
                o1.amount = rd.GetInt32(3);
                o1.orderdate = rd.GetDateTime(4).ToShortDateString();
            }
            con.Close();
        }

        /*Accept Payment Form: search for OrderID*/
        public string searchOrderID(string id)
        {
            string status = null;
            con.Open();
            SqlCommand cmd = new SqlCommand("select count(*) from Service where OrderID ='" + orderID + "'", con);
            SqlCommand cmd2 = new SqlCommand("select PaymentMethod from Service where OrderID ='" + orderID + "'", con);
            int i = Convert.ToInt32(cmd.ExecuteScalar().ToString());
            if (i > 0)
            {
                PaymentReceipt payre = new PaymentReceipt(id);

                /*Reject Display if PaymentMethod exists */
                string pay = cmd2.ExecuteScalar().ToString();
                if (String.IsNullOrEmpty(pay))
                {
                    status = null;
                }
                else
                    status = "Payment Already Done";
            }
            else
            {
                status = "OrderID Not Found!";
            }
            con.Close();
            return status;

        }

        /* AcceptPayment Form ： Display*/
        public static void acceptpayview(Service o1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select FullName,Service,Amount from Service where OrderID ='" + o1.orderID + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                o1.fullName = rd.GetString(0);
                o1.cusservice = rd.GetString(1);
                o1.amount = rd.GetInt32(2);
            }
            con.Close();
        }

        /*AccpetPayment Form : Update Service (PaymentMethod)*/
        public string acceptPayment(string method)
        {
            con.Open();
            collectiondate = DateTime.Now.ToString("MM/dd/yyyy");
            payment = method;
            SqlCommand cmd = new SqlCommand("update Service set PaymentMethod ='" + payment + "' where OrderID ='" + orderID + "'", con);
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Transaction Done";
            else
                status = "Transaction Failed";
            con.Close();
            return status;

        }
        /*PaymentReceipt Form: Display*/
        public static void viewReceipt(Service o1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select OrderID,FullName,Service,Amount from Service where OrderID ='" + o1.OrderID + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                o1.orderID = rd.GetString(0);
                o1.fullName = rd.GetString(1);
                o1.cusservice = rd.GetString(2);
                o1.amount = rd.GetInt32(3);

            }
            con.Close();
        }

        //frmViewServiceRequested(step1) before choosing Order ID to show details
        public static void viewCusname(Service o1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select FullName from Service where Username ='" + o1.userName + "'", con);
            o1.fullName = cmd.ExecuteScalar().ToString();
            con.Close();
        }

        //frmViewServiceRequested(step2) search Order ID(s) under the username
        public static ArrayList searchcusOrderID(string un)
        {
            ArrayList idList = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("select OrderID from Service where Username ='" + un + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                idList.Add(rd.GetString(0));
            }
            con.Close();
            return idList;
        }

        //frmViewServiceRequested(step3) after choosing which Order ID to view
        public static void viewCusService(Service o1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Service where OrderID = '" + o1.orderID + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                o1.cusservice = rd.GetString(4);
                o1.amount = rd.GetInt32(5);
                o1.status = rd.GetString(7);
                o1.orderdate = rd.GetDateTime(8).ToShortDateString();

                if (rd.IsDBNull(9) == true)
                    o1.description = String.Empty;
                else
                    o1.description = rd.GetString(9);

                if (rd.IsDBNull(10) == true)
                    o1.collectiondate = String.Empty;
                else
                    o1.collectiondate = rd.GetDateTime(10).ToShortDateString();
            }

            con.Close();
        }

        //frmCustomerMenu frmChangeServiceMenu(step1) is there any incomplete order to change service?
        public string checkOrderID()
        {
            string stat = null;
            con.Open();

            SqlCommand cmd = new SqlCommand("select count(*) from Service where Username ='" + userName + "' and Status ='Pending'", con);
            int i = Convert.ToInt32(cmd.ExecuteScalar().ToString());
            if (i != 1)
                stat = "No order is available to change service now.";
            con.Close();

            return stat;
        }

        //frmChangeServiceMenu(step2) showing original service selected
        public static void viewServiceselected(Service o1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select Service from Service where Username = '" + o1.userName + "' and Status ='Pending'", con);
            o1.cusservice = cmd.ExecuteScalar().ToString();
            con.Close();
        }

        //frmChangeServiceMenu(step3) update in database
        public string updateService(string s, int p)
        {
            string stat = string.Empty;
            con.Open();

            cusservice = s;
            amount = p;

            //found the orderID
            SqlCommand cmd = new SqlCommand("select OrderID from Service where Username ='" + userName + "' and Status ='Pending'", con);
            orderID = cmd.ExecuteScalar().ToString();

            //update service & amount in database
            SqlCommand cmd1 = new SqlCommand("update Service set Service ='" + cusservice + "',Amount ='" + amount + "'where OrderID ='" + orderID + "'", con);
            int i = cmd1.ExecuteNonQuery();

            if (i != 0)
                stat = "Service Changed Successfully.";
            else
                stat = "Unable to Change Service.";

            con.Close();

            return stat;
        }

        public static ArrayList viewAll(Service o2)
        {

            //arraylist to create dynamic array
            ArrayList nm = new ArrayList();
            con.Open();

            string text3 = (o2.orderdate + "%%");
            //Convert.ToDateTime(text);           

            SqlCommand cmd = new SqlCommand("Select OrderID,OrderDate,Service from Service where orderdate like ('" + text3 + "')", con);
            SqlDataReader rd = cmd.ExecuteReader();

            while (rd.Read())
            {
                string hd = $"{(object)(rd.GetString(0)),-12 }{(object)(rd.GetDateTime(1).ToString("dd/MM/yyyy")),-15 }  {(object)(rd.GetString(2)),-25} ";
                //string hd = string.Format("(0,-12) | (0,-15) | (0,-25) | (0,-25)", (rd.GetString(0), rd.GetDateTime(1).ToString("dd/MM/yyyy"), rd.GetString(2), rd.GetString(3));
                //string yd = $"{ (object)(rd.GetString(3)),-0}";
                //nm.Add(rd.GetString(0)+"      "+rd.GetDateTime(1).ToString("dd/MM/yyyy")+"       "+ rd.GetString(2)+"             " + rd.GetString(3));
                nm.Add(hd);
            }
            con.Close();

            return nm;
        }
        public static ArrayList viewIncome(Service o3)
        {

            //arraylist to create dynamic array
            ArrayList nm = new ArrayList();
            con.Open();

            string text = (o3.orderdate + "%%");


            SqlCommand cmd = new SqlCommand("Select OrderID,OrderDate,Amount from Service where orderdate like ('" + text + "')", con);
            SqlDataReader rd = cmd.ExecuteReader();

            while (rd.Read())
            {
                string hd = $"{(object)(rd.GetString(0)),-12 }{(object)(rd.GetDateTime(1).ToString("dd/MM/yyyy")),-18 }RM{(object)(rd.GetInt32(2).ToString()),-25} ";

                nm.Add(hd);
            }

            con.Close();

            return nm;
        }
        public static ArrayList ViewTotalIncome(Service o3)
        {
            ArrayList nm = new ArrayList();
            con.Open();
            string text = (o3.orderdate + "%%");
            using var cmd2 = new SqlCommand("Select sum(Amount) from Service where orderdate like ('" + text + "')", con);
            var rd2 = cmd2.ExecuteScalar();

            if (rd2 != DBNull.Value)
            {
                nm.Add(rd2.ToString());

            }
            else
            {
                nm.Add("0");
            }
            con.Close();
            return nm;
        }

    }
}
