﻿namespace Assigmnet
{
    partial class frmService
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstMenu = new System.Windows.Forms.ListBox();
            this.cmbService = new System.Windows.Forms.ComboBox();
            this.lblSelect = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstMenu
            // 
            this.lstMenu.FormattingEnabled = true;
            this.lstMenu.ItemHeight = 32;
            this.lstMenu.Items.AddRange(new object[] {
            "\tService Type\t\t\tNormal\tUrgent\t",
            "1. Remove virus, malware or spyware\t\tRM50\tRM80",
            "2. Troubleshot and fix computer running slow\tRM60\tRM90",
            "3. Laptop screen replacement\t\tRM380\tRM430",
            "4. Laptop keyboard replacement \t\tRM 160 \tRM200",
            "5. Laptop battery replacement \t\tRM 180 \tRM210",
            "6. Operating System Format and Installation \tRM 100\tRM150",
            "7. Data backup and recovery \t\tRM 80 \tRM130",
            "8. Internet connectivity issues \t\tRM 70 \tRM100"});
            this.lstMenu.Location = new System.Drawing.Point(77, 110);
            this.lstMenu.Name = "lstMenu";
            this.lstMenu.ScrollAlwaysVisible = true;
            this.lstMenu.Size = new System.Drawing.Size(819, 324);
            this.lstMenu.TabIndex = 0;
            this.lstMenu.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // cmbService
            // 
            this.cmbService.FormattingEnabled = true;
            this.cmbService.Items.AddRange(new object[] {
            "Remove virus, malware or spyware ",
            "Remove virus, malware or spyware (Urgent)",
            "Troubleshot and fix computer running slow",
            "Troubleshot and fix computer running slow (Urgent)",
            "Laptop screen replacement",
            "Laptop screen replacement (Urgent)",
            "Laptop screen replacement",
            "Laptop screen replacement (Urgent)",
            "Laptop battery replacement",
            "Laptop battery replacement （Urgent)",
            "Operating System Format and Installation",
            "Operating System Format and Installation (Urgent)",
            "Data backup and recovery",
            "Data backup and recovery (Urgent)",
            "Internet connectivity issues",
            "Internet connectivity issue (Urgent)"});
            this.cmbService.Location = new System.Drawing.Point(184, 523);
            this.cmbService.Name = "cmbService";
            this.cmbService.Size = new System.Drawing.Size(622, 40);
            this.cmbService.TabIndex = 1;
            this.cmbService.Text = "-None-";
            this.cmbService.SelectedIndexChanged += new System.EventHandler(this.cmbService_SelectedIndexChanged);
            // 
            // lblSelect
            // 
            this.lblSelect.AutoSize = true;
            this.lblSelect.Location = new System.Drawing.Point(386, 474);
            this.lblSelect.Name = "lblSelect";
            this.lblSelect.Size = new System.Drawing.Size(180, 32);
            this.lblSelect.TabIndex = 2;
            this.lblSelect.Text = "Select a Service";
            this.lblSelect.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.lblTitle.Location = new System.Drawing.Point(356, 46);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(257, 38);
            this.lblTitle.TabIndex = 3;
            this.lblTitle.Text = "Service Menu";
            this.lblTitle.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNext.Location = new System.Drawing.Point(770, 599);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(150, 46);
            this.btnNext.TabIndex = 4;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Location = new System.Drawing.Point(24, 599);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(150, 46);
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnConfirm.Location = new System.Drawing.Point(416, 599);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(150, 46);
            this.btnConfirm.TabIndex = 6;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // frmService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(932, 657);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblSelect);
            this.Controls.Add(this.cmbService);
            this.Controls.Add(this.lstMenu);
            this.Name = "frmService";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Laptop Repair Services Management System";
            this.Load += new System.EventHandler(this.frmService_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ListBox lstMenu;
        private ComboBox cmbService;
        private Label lblSelect;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Label lblTitle;
        private Button btnNext;
        private Button btnBack;
        private Button btnConfirm;
    }
}