﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace AssignmentTechnician
{
    internal class Staff
    {
        private string staffUsername;
        private string staffFullName;
        private string staffcontactNum;
        private string staffEmail;
        private string staffgender;
        private string staffPassword;
        private string YearRPT;
        private string MonthRPT;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public string StaffUsername { get => staffUsername; set => staffUsername = value; }
        public string StaffFullName { get => staffFullName; set => staffFullName = value; }
        public string StaffcontactNum { get => staffcontactNum; set => staffcontactNum = value; }
        public string StaffEmail { get => staffEmail; set => staffEmail = value; }
        public string Staffgender { get => staffgender; set => staffgender = value; }
        public string YearRPT1 { get => YearRPT; set => YearRPT = value; }
        public string MonthRPT1 { get => MonthRPT; set => MonthRPT = value; }

        public Staff(string usname)
        {
            staffUsername = usname;
        }


        public Staff(string usern, string name, string num, string em, string gen, string pass)
        {
            staffUsername = usern;
            staffFullName = name;
            staffcontactNum = num;
            staffEmail = em;
            staffgender = gen;
            staffPassword = pass;
        }


        public string updateStaffPhone(string phnum)
        {
            string status;
            con.Open();

            staffcontactNum = phnum;
            SqlCommand cmd = new SqlCommand("select count(*) from Customer where ContactNum ='" + staffcontactNum + "'", con);
            SqlCommand cmd2 = new SqlCommand("select count(*) from Staff where ContactNum ='" + staffcontactNum + "'", con);
            SqlCommand cmd3= new SqlCommand("update Staff set ContactNum = '" + staffcontactNum +"' where staffusername ='"+staffUsername+"'",con);
            int checkPhCus = Convert.ToInt32(cmd.ExecuteScalar());
            int checkPhStaff = Convert.ToInt32(cmd2.ExecuteScalar());
            if ((checkPhCus > 0) || (checkPhStaff > 0))
            {
                MessageBox.Show("Phone Number already exist!");
                status = " Update Unucccessful!";
            }
            else
            {
                int i = cmd3.ExecuteNonQuery();
                if (i == 0)
                    status = "Unable to update.";
                else
                    status = "Update Successfully";
            }
            con.Close();

            return status;
            
        }

        public string updateStaffEmail(string em)
        {
            con.Open();
            string status;
            staffEmail = em;
            SqlCommand cmd4 = new SqlCommand("select count(*) from Customer where Email ='" + staffEmail + "'", con);
            SqlCommand cmd5 = new SqlCommand("select count(*) from Staff where Email ='" + staffEmail + "'", con);
            SqlCommand cmd6 = new SqlCommand("update Staff set Email ='" + staffEmail + "' where staffusername ='" + staffUsername + "'", con);
            int checkEmailCus = Convert.ToInt32(cmd4.ExecuteScalar());
            int checkEmailStaff = Convert.ToInt32(cmd5.ExecuteScalar());
            if ((checkEmailCus > 0) || (checkEmailStaff > 0))
            {
                MessageBox.Show("Email already exist!");
                status = " Update Unucccessful!";
            }
            else
            {
                int i = cmd6.ExecuteNonQuery();
                if (i == 0)
                    status = "Unable to update.";
                else
                    status = "Update Successfully";
            }
            con.Close();

            return status;
        }

        public static void viewProfile(Staff o1)//view staff profile //
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Staff where staffusername ='" + o1.staffUsername + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while(rd.Read())
            {
                o1.staffUsername = rd.GetString(1);
                o1.staffFullName=rd.GetString(2);
                o1.staffcontactNum= rd.GetString(3);
                o1.staffEmail = rd.GetString(4);
                o1.staffgender = rd.GetString(5);
            }
            con.Close();
        }

        public string addReceptionist()
        {
            string status;
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert into Staff (Staffusername,Fullname,ContactNum,Email,Gender) values(@usern, @name, @num, @em, @gen)", con);

            //Below is logic to prevent duplicate username registration for login
            /*
            select count(*) from users where username = @name
            if the count > 0, that means username already exist,
            thus you should show error msg
            else execute insert into statement (cmd2)
            */

            SqlCommand cmd2 = new SqlCommand("Insert into users (username, password, role) values (@usern, @pass, 'receptionist')", con);
            cmd.Parameters.AddWithValue("@usern", staffUsername);
            cmd.Parameters.AddWithValue("@name", staffFullName);
            cmd.Parameters.AddWithValue("@num", staffcontactNum);
            cmd.Parameters.AddWithValue("@em", staffEmail);
            cmd.Parameters.AddWithValue("@gen", staffgender);
            cmd2.Parameters.AddWithValue("@usern", staffUsername);
            cmd2.Parameters.AddWithValue("@pass", staffPassword);


            cmd2.ExecuteNonQuery();
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
            {
                status = "Registration Successful For Receptionist.";
            }
            else
            {
                status = "Unable To Register.";
            }
            con.Close();

            return status;
        }
        public string addTechnician()
        {
            string status;
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert into Staff (Staffusername,Fullname,ContactNum,Email,Gender) values(@usern, @name, @num, @em, @gen)", con);

            SqlCommand cmd2 = new SqlCommand("Insert into users (username, password, role) values (@usern, @pass, 'technician')", con);
            cmd.Parameters.AddWithValue("@usern", staffUsername);
            cmd2.Parameters.AddWithValue("@usern", staffUsername);
            cmd2.Parameters.AddWithValue("@pass", staffPassword);
            cmd.Parameters.AddWithValue("@name", staffFullName);
            cmd.Parameters.AddWithValue("@num", staffcontactNum);
            cmd.Parameters.AddWithValue("@em", staffEmail);
            cmd.Parameters.AddWithValue("@gen", staffgender);

            cmd2.ExecuteNonQuery();
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
            {
                status = "Registration Successful For Technician.";
            }
            else
            {
                status = "Unable To Register.";
            }
            con.Close();

            return status;
        }
    }
}
