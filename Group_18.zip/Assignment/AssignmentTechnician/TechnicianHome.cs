namespace AssignmentTechnician
{
    public partial class TechnicianHome : Form
    {
        public string username;
        public string password;
        public TechnicianHome()
        {
            InitializeComponent();
        }

        public TechnicianHome(string usn,string pass)
        {
            InitializeComponent();
            username = usn;
            password = pass;
        }

        private void btnService_Click(object sender, EventArgs e)
        {
            frmServiceRequested obj = new frmServiceRequested();
            obj.ShowDialog();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmCompletion obj1 = new frmCompletion();
            obj1.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            frmUpdateProfile obj2 = new frmUpdateProfile(username,password);
            obj2.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TechnicianHome_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = "Welcome "+username;
        }
    }
}