﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using IoopAssignment;
using IOOPFORM;

namespace AssignmentTechnician
{
    internal class User
    {
        private string username;
        private string password;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public User(string un, string pw)
        {
            username = un;
            password = pw;
        }

        public User(string un)
        {
            username=un;
        }

        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        
        public string login(string un)//Login Page by using Login Method)
        {
            string status = null;
            con.Open();

            SqlCommand cmd = new SqlCommand("select count (*) from users where username ='" + username + "'and password ='" + password + "'", con);

            int count = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (count > 0)
            {
                SqlCommand cmd2 = new SqlCommand("select role from users where username ='" + username + "'and password ='" + password + "'", con);
                string userRole = cmd2.ExecuteScalar().ToString();

                if (userRole == "technician")
                {
                    TechnicianHome t = new TechnicianHome(username, password);
                    t.ShowDialog();
                }
                else if (userRole == "customer")
                {
                    frmCustomerMenu c = new frmCustomerMenu(username, password);
                    c.ShowDialog();
                }
                else if (userRole == "receptionist")
                {
                    Assigmnet.ReceptionistMenu r = new Assigmnet.ReceptionistMenu(username,password);
                    frmUpdateProfile u = new frmUpdateProfile(username);
                    r.ShowDialog();
                }
                else if (userRole == "admin")
                {
                    Menu m = new Menu(username);
                    m.ShowDialog();
                    con.Close();
                }
            }
            else
                status = "Incorrect username/password";
            con.Close();

            return status;
        }

        public string updatePass(string oldPass, string newPass, string confirmPass)
        {
            //frmResetPass to Reset Password (by entering okd password,new password and confirm password)
            con.Open();
            string status = null;
            string oldpassword = oldPass;
            string newpassword = newPass;
            string confirmpassword = confirmPass;
            if (oldpassword == password)
            {
                Regex hasNumber = new Regex(@"[0-9]+");
                Regex hasUpperChar = new Regex(@"[!A-Z]+");
                Regex hasMinimum12Chars = new Regex(@".{12,}");
                Regex hasLowerChar = new Regex(@"[a-z]+");
                Regex hasSymbols = new Regex(@"[!@#$%^&*()_+=\[{\]};:<>|./?,-]");
                bool isValidated = hasNumber.IsMatch(newpassword) && hasUpperChar.IsMatch(newpassword) && hasMinimum12Chars.IsMatch(newpassword) && hasLowerChar.IsMatch(newpassword) && hasSymbols.IsMatch(newpassword);

                if (isValidated == true)
                {
                    if (newpassword == confirmpassword)
                    {
                        SqlCommand cmd1 = new SqlCommand("update users set password ='" + newpassword + "'where username ='" + username + "'", con);
                        int i = cmd1.ExecuteNonQuery();
                        if (i != 0)
                        {
                            status = "Update Successfully.";
                        }
                        else
                        {
                            status = "Unable to update.";
                        }
                    }
                    else
                        status = "The confirm new password is incorrect ,please try again";
                }
                else if (isValidated == false)
                {
                    status = "New password must contain at least a number ,one upper case letter,one lower case letter ,one symbol(min12 characters)";
                }
            }
            else
                status = "The old password is wrongly enter\nPlease enter again.:)";
            con.Close();
            return status;
        }
        public string checkRole()
        {
            string role;
            con.Open();
            SqlCommand cmd = new SqlCommand("select role from users where username ='" + username + "'", con);
            role = cmd.ExecuteScalar().ToString();
            con.Close();
            return role;
        }
    }
}
