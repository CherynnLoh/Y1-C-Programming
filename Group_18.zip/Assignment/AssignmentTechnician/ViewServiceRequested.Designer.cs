﻿namespace IoopAssignment
{
    partial class frmViewServiceRequested
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblOrderID0 = new System.Windows.Forms.Label();
            this.lblAmount0 = new System.Windows.Forms.Label();
            this.lblDescription0 = new System.Windows.Forms.Label();
            this.lblService0 = new System.Windows.Forms.Label();
            this.lblUsername0 = new System.Windows.Forms.Label();
            this.lblCollectionDate0 = new System.Windows.Forms.Label();
            this.lblStatus0 = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblFullName = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblService = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.lblCollectionDate = new System.Windows.Forms.Label();
            this.lblFullName0 = new System.Windows.Forms.Label();
            this.cmbOrderID = new System.Windows.Forms.ComboBox();
            this.lblOrderDate0 = new System.Windows.Forms.Label();
            this.lblOrderDate = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.lblTitle.Location = new System.Drawing.Point(204, 46);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(321, 28);
            this.lblTitle.TabIndex = 3;
            this.lblTitle.Text = "View Service Requested";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblTitle.Click += new System.EventHandler(this.lblTitle_Click);
            // 
            // lblOrderID0
            // 
            this.lblOrderID0.AutoSize = true;
            this.lblOrderID0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblOrderID0.Location = new System.Drawing.Point(186, 143);
            this.lblOrderID0.Name = "lblOrderID0";
            this.lblOrderID0.Size = new System.Drawing.Size(84, 20);
            this.lblOrderID0.TabIndex = 4;
            this.lblOrderID0.Text = "Order ID: ";
            // 
            // lblAmount0
            // 
            this.lblAmount0.AutoSize = true;
            this.lblAmount0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAmount0.Location = new System.Drawing.Point(84, 379);
            this.lblAmount0.Name = "lblAmount0";
            this.lblAmount0.Size = new System.Drawing.Size(198, 20);
            this.lblAmount0.TabIndex = 5;
            this.lblAmount0.Text = "Total Amount to be Paid: ";
            // 
            // lblDescription0
            // 
            this.lblDescription0.AutoSize = true;
            this.lblDescription0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDescription0.Location = new System.Drawing.Point(114, 311);
            this.lblDescription0.Name = "lblDescription0";
            this.lblDescription0.Size = new System.Drawing.Size(166, 20);
            this.lblDescription0.TabIndex = 6;
            this.lblDescription0.Text = "Service Description: ";
            // 
            // lblService0
            // 
            this.lblService0.AutoSize = true;
            this.lblService0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblService0.Location = new System.Drawing.Point(118, 221);
            this.lblService0.Name = "lblService0";
            this.lblService0.Size = new System.Drawing.Size(160, 20);
            this.lblService0.TabIndex = 7;
            this.lblService0.Text = "Service Requested: ";
            this.lblService0.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblUsername0
            // 
            this.lblUsername0.AutoSize = true;
            this.lblUsername0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblUsername0.Location = new System.Drawing.Point(78, 94);
            this.lblUsername0.Name = "lblUsername0";
            this.lblUsername0.Size = new System.Drawing.Size(96, 20);
            this.lblUsername0.TabIndex = 8;
            this.lblUsername0.Text = "Username: ";
            // 
            // lblCollectionDate0
            // 
            this.lblCollectionDate0.AutoSize = true;
            this.lblCollectionDate0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblCollectionDate0.Location = new System.Drawing.Point(92, 422);
            this.lblCollectionDate0.Name = "lblCollectionDate0";
            this.lblCollectionDate0.Size = new System.Drawing.Size(190, 20);
            this.lblCollectionDate0.TabIndex = 9;
            this.lblCollectionDate0.Text = "Laptop Collection Date: ";
            // 
            // lblStatus0
            // 
            this.lblStatus0.AutoSize = true;
            this.lblStatus0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblStatus0.Location = new System.Drawing.Point(200, 265);
            this.lblStatus0.Name = "lblStatus0";
            this.lblStatus0.Size = new System.Drawing.Size(67, 20);
            this.lblStatus0.TabIndex = 10;
            this.lblStatus0.Text = "Status: ";
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnConfirm.Location = new System.Drawing.Point(594, 495);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(106, 26);
            this.btnConfirm.TabIndex = 13;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBack.Location = new System.Drawing.Point(12, 495);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(106, 26);
            this.btnBack.TabIndex = 12;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblFullName
            // 
            this.lblFullName.AutoSize = true;
            this.lblFullName.BackColor = System.Drawing.Color.GhostWhite;
            this.lblFullName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblFullName.Location = new System.Drawing.Point(472, 92);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new System.Drawing.Size(2, 22);
            this.lblFullName.TabIndex = 14;
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.BackColor = System.Drawing.Color.GhostWhite;
            this.lblUsername.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblUsername.Location = new System.Drawing.Point(182, 92);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(2, 22);
            this.lblUsername.TabIndex = 15;
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.BackColor = System.Drawing.Color.GhostWhite;
            this.lblService.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblService.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblService.Location = new System.Drawing.Point(277, 221);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(2, 22);
            this.lblService.TabIndex = 16;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.BackColor = System.Drawing.Color.GhostWhite;
            this.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblStatus.Location = new System.Drawing.Point(277, 265);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(2, 22);
            this.lblStatus.TabIndex = 17;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.BackColor = System.Drawing.Color.GhostWhite;
            this.lblDescription.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDescription.Location = new System.Drawing.Point(277, 311);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(2, 22);
            this.lblDescription.TabIndex = 18;
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.BackColor = System.Drawing.Color.GhostWhite;
            this.lblAmount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAmount.Location = new System.Drawing.Point(277, 379);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(2, 22);
            this.lblAmount.TabIndex = 19;
            // 
            // lblCollectionDate
            // 
            this.lblCollectionDate.AutoSize = true;
            this.lblCollectionDate.BackColor = System.Drawing.Color.GhostWhite;
            this.lblCollectionDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCollectionDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblCollectionDate.Location = new System.Drawing.Point(277, 422);
            this.lblCollectionDate.Name = "lblCollectionDate";
            this.lblCollectionDate.Size = new System.Drawing.Size(2, 22);
            this.lblCollectionDate.TabIndex = 20;
            // 
            // lblFullName0
            // 
            this.lblFullName0.AutoSize = true;
            this.lblFullName0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblFullName0.Location = new System.Drawing.Point(370, 92);
            this.lblFullName0.Name = "lblFullName0";
            this.lblFullName0.Size = new System.Drawing.Size(95, 20);
            this.lblFullName0.TabIndex = 21;
            this.lblFullName0.Text = "Full Name: ";
            // 
            // cmbOrderID
            // 
            this.cmbOrderID.FormattingEnabled = true;
            this.cmbOrderID.Location = new System.Drawing.Point(277, 140);
            this.cmbOrderID.Name = "cmbOrderID";
            this.cmbOrderID.Size = new System.Drawing.Size(151, 28);
            this.cmbOrderID.TabIndex = 22;
            // 
            // lblOrderDate0
            // 
            this.lblOrderDate0.AutoSize = true;
            this.lblOrderDate0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblOrderDate0.Location = new System.Drawing.Point(169, 181);
            this.lblOrderDate0.Name = "lblOrderDate0";
            this.lblOrderDate0.Size = new System.Drawing.Size(103, 20);
            this.lblOrderDate0.TabIndex = 23;
            this.lblOrderDate0.Text = "Order Date: ";
            // 
            // lblOrderDate
            // 
            this.lblOrderDate.AutoSize = true;
            this.lblOrderDate.BackColor = System.Drawing.Color.GhostWhite;
            this.lblOrderDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOrderDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblOrderDate.Location = new System.Drawing.Point(277, 181);
            this.lblOrderDate.Name = "lblOrderDate";
            this.lblOrderDate.Size = new System.Drawing.Size(2, 22);
            this.lblOrderDate.TabIndex = 24;
            // 
            // frmViewServiceRequested
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(712, 533);
            this.Controls.Add(this.lblOrderDate);
            this.Controls.Add(this.lblOrderDate0);
            this.Controls.Add(this.cmbOrderID);
            this.Controls.Add(this.lblFullName0);
            this.Controls.Add(this.lblCollectionDate);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblService);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.lblFullName);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lblStatus0);
            this.Controls.Add(this.lblCollectionDate0);
            this.Controls.Add(this.lblUsername0);
            this.Controls.Add(this.lblService0);
            this.Controls.Add(this.lblDescription0);
            this.Controls.Add(this.lblAmount0);
            this.Controls.Add(this.lblOrderID0);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "frmViewServiceRequested";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Laptop Repair Services Management System";
            this.Load += new System.EventHandler(this.frmViewServiceRequested_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private Label lblOrderID0;
        private Label lblAmount0;
        private Label lblDescription0;
        private Label lblService0;
        private Label lblUsername0;
        private Label lblCollectionDate0;
        private Label lblStatus0;
        private Button btnConfirm;
        private Button btnBack;
        private Label lblFullName;
        private Label lblUsername;
        private Label lblService;
        private Label lblStatus;
        private Label lblDescription;
        private Label lblAmount;
        private Label lblCollectionDate;
        private Label lblFullName0;
        private ComboBox cmbOrderID;
        private Label lblOrderDate0;
        private Label lblOrderDate;
    }
}