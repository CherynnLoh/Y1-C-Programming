﻿using AssignmentTechnician;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IoopAssignment
{
    public partial class frmViewServiceRequested : Form
    {
        public static string name;
        public frmViewServiceRequested()
        {
            InitializeComponent();
        }
        public frmViewServiceRequested(string n)
        {
            InitializeComponent();
            name = n;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void frmViewServiceRequested_Load(object sender, EventArgs e)
        {
            Service obj1 = new Service(name);

            //view username and full name
            Service.viewCusname(obj1);
            lblUsername.Text = name;
            lblFullName.Text = obj1.FullName;

            //find orderID(s) into combobox corresponding to the username
            ArrayList orderIDlist = new ArrayList();
            orderIDlist = Service.searchcusOrderID(name);
            foreach (var item in orderIDlist)
            {
                cmbOrderID.Items.Add(item);
            }
        }



        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (cmbOrderID.SelectedIndex >= 0)
            {
                Service obj1 = new Service(cmbOrderID.SelectedItem.ToString());
                Service.viewCusService(obj1);

                lblOrderDate.Text = obj1.Orderdate;
                lblService.Text = obj1.Cusservice;
                lblStatus.Text = obj1.Status;
                lblDescription.Text = obj1.Description;
                lblAmount.Text = "RM"+obj1.Amount.ToString("f2");
                lblCollectionDate.Text = obj1.Collectiondate;
            }
            else
            {
                MessageBox.Show("Select an Order ID to proceed");
            }
        }
    }
}
