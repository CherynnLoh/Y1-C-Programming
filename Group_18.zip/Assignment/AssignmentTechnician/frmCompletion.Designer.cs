﻿namespace AssignmentTechnician
{
    partial class frmCompletion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtOrderID = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblShowservice = new System.Windows.Forms.Label();
            this.lblShownm = new System.Windows.Forms.Label();
            this.txtDes = new System.Windows.Forms.TextBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnDone = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.lblShowodrdate = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.lblShowusnm = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblShowcollectdate = new System.Windows.Forms.Label();
            this.grbDetails = new System.Windows.Forms.GroupBox();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Verdana", 11.8209F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.lblTitle.Location = new System.Drawing.Point(208, 29);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(294, 28);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "Completion of Service";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.LightYellow;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.134328F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.label2.Location = new System.Drawing.Point(140, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Username :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(161, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "Order ID :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(107, 299);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 23);
            this.label7.TabIndex = 5;
            this.label7.Text = "Add Description :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(52, 378);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(194, 23);
            this.label9.TabIndex = 6;
            this.label9.Text = "Laptop Collection Date :";
            // 
            // txtOrderID
            // 
            this.txtOrderID.Location = new System.Drawing.Point(252, 72);
            this.txtOrderID.Name = "txtOrderID";
            this.txtOrderID.Size = new System.Drawing.Size(250, 30);
            this.txtOrderID.TabIndex = 7;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSearch.Location = new System.Drawing.Point(508, 75);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 27);
            this.btnSearch.TabIndex = 9;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.LightYellow;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.134328F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.label5.Location = new System.Drawing.Point(161, 225);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "Service :";
            this.label5.Click += new System.EventHandler(this.lblService_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LightYellow;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.134328F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.label3.Location = new System.Drawing.Point(176, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Name :";
            // 
            // lblShowservice
            // 
            this.lblShowservice.AutoSize = true;
            this.lblShowservice.BackColor = System.Drawing.Color.GhostWhite;
            this.lblShowservice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShowservice.Location = new System.Drawing.Point(252, 225);
            this.lblShowservice.Name = "lblShowservice";
            this.lblShowservice.Size = new System.Drawing.Size(2, 25);
            this.lblShowservice.TabIndex = 18;
            // 
            // lblShownm
            // 
            this.lblShownm.AutoSize = true;
            this.lblShownm.BackColor = System.Drawing.Color.GhostWhite;
            this.lblShownm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShownm.Location = new System.Drawing.Point(252, 160);
            this.lblShownm.Name = "lblShownm";
            this.lblShownm.Size = new System.Drawing.Size(2, 25);
            this.lblShownm.TabIndex = 16;
            // 
            // txtDes
            // 
            this.txtDes.Location = new System.Drawing.Point(252, 299);
            this.txtDes.Name = "txtDes";
            this.txtDes.Size = new System.Drawing.Size(331, 30);
            this.txtDes.TabIndex = 19;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Location = new System.Drawing.Point(52, 421);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(105, 32);
            this.btnBack.TabIndex = 21;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnDone
            // 
            this.btnDone.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnDone.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDone.Location = new System.Drawing.Point(568, 421);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(105, 32);
            this.btnDone.TabIndex = 22;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = false;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(252, 340);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(331, 30);
            this.dateTimePicker1.TabIndex = 23;
            this.dateTimePicker1.Value = new System.DateTime(2022, 6, 9, 0, 0, 0, 0);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(183, 263);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 23);
            this.label6.TabIndex = 24;
            this.label6.Text = "Status :";
            // 
            // lblShowodrdate
            // 
            this.lblShowodrdate.AutoSize = true;
            this.lblShowodrdate.BackColor = System.Drawing.Color.GhostWhite;
            this.lblShowodrdate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShowodrdate.Location = new System.Drawing.Point(252, 192);
            this.lblShowodrdate.Name = "lblShowodrdate";
            this.lblShowodrdate.Size = new System.Drawing.Size(2, 25);
            this.lblShowodrdate.TabIndex = 27;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.LightYellow;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.134328F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.MediumVioletRed;
            this.label4.Location = new System.Drawing.Point(130, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 20);
            this.label4.TabIndex = 26;
            this.label4.Text = "Order Date :";
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(252, 259);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(331, 30);
            this.txtStatus.TabIndex = 28;
            // 
            // lblShowusnm
            // 
            this.lblShowusnm.AutoSize = true;
            this.lblShowusnm.BackColor = System.Drawing.Color.GhostWhite;
            this.lblShowusnm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShowusnm.Location = new System.Drawing.Point(252, 124);
            this.lblShowusnm.Name = "lblShowusnm";
            this.lblShowusnm.Size = new System.Drawing.Size(2, 25);
            this.lblShowusnm.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(50, 340);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(198, 23);
            this.label8.TabIndex = 30;
            this.label8.Text = "Choose Collection Date :";
            // 
            // lblShowcollectdate
            // 
            this.lblShowcollectdate.AutoSize = true;
            this.lblShowcollectdate.BackColor = System.Drawing.Color.GhostWhite;
            this.lblShowcollectdate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShowcollectdate.Location = new System.Drawing.Point(252, 378);
            this.lblShowcollectdate.Name = "lblShowcollectdate";
            this.lblShowcollectdate.Size = new System.Drawing.Size(2, 25);
            this.lblShowcollectdate.TabIndex = 31;
            // 
            // grbDetails
            // 
            this.grbDetails.BackColor = System.Drawing.Color.LightYellow;
            this.grbDetails.Font = new System.Drawing.Font("Segoe UI", 9.134328F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.grbDetails.Location = new System.Drawing.Point(50, 108);
            this.grbDetails.Name = "grbDetails";
            this.grbDetails.Size = new System.Drawing.Size(623, 145);
            this.grbDetails.TabIndex = 32;
            this.grbDetails.TabStop = false;
            this.grbDetails.Text = "Details";
            // 
            // frmCompletion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(699, 469);
            this.Controls.Add(this.lblShowcollectdate);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblShowusnm);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.lblShowodrdate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.txtDes);
            this.Controls.Add(this.lblShowservice);
            this.Controls.Add(this.lblShownm);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtOrderID);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.grbDetails);
            this.Name = "frmCompletion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Laptop Repair Services Management System";
            this.Load += new System.EventHandler(this.Completion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private Label label2;
        private Label label1;
        private Label label7;
        private Label label9;
        private TextBox txtOrderID;
        private Button btnSearch;
        private Label label5;
        private Label label3;
        private Label lblShowservice;
        private Label lblShownm;
        private TextBox txtDes;
        private Button btnBack;
        private Button btnDone;
        private DateTimePicker dateTimePicker1;
        private Label label6;
        private Label lblShowodrdate;
        private Label label4;
        private TextBox txtStatus;
        private Label lblShowusnm;
        private Label label8;
        private Label lblShowcollectdate;
        private GroupBox grbDetails;
    }
}