﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AssignmentTechnician
{
    public partial class frmCompletion : Form
    {
        public frmCompletion()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            Service obj2 = new Service(txtOrderID.Text);
            MessageBox.Show(obj2.updateDesCollection(txtStatus.Text,txtDes.Text, dateTimePicker1.Value.Date.ToString("MM/dd/yyyy")));
            txtDes.Enabled = false;
            txtStatus.Enabled=false;
            lblShowcollectdate.Text = dateTimePicker1.Value.Date.ToString("dd/MM/yyyy");
            dateTimePicker1.Enabled=false;
            btnDone.Enabled=false;
        }

        private void lblService_Click(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string stat;
            Service obj1 = new Service(txtOrderID.Text);
            stat = obj1.checkOrderID(txtOrderID.Text);
            if (stat == null)
            {
                Service.viewService(obj1);
                lblShowusnm.Text = obj1.UserName;
                lblShownm.Text = obj1.FullName;
                lblShowservice.Text = obj1.Cusservice;
                lblShowodrdate.Text = obj1.Orderdate;
                txtDes.Text = obj1.Description;
                txtStatus.Text = obj1.Status;
                if (obj1.Status == "Complete")
                {
                    btnDone.Enabled = false;
                    txtDes.Enabled = false;
                    txtStatus.Enabled = false;
                    dateTimePicker1.Enabled = false;
                    lblShowcollectdate.Text = obj1.Collectiondate;
                }
                else
                {
                    txtStatus.Text = "Complete";
                    txtDes.Text = obj1.Description;
                    btnDone.Enabled = true;
                    txtDes.Enabled = true;
                    txtStatus.Enabled = true;
                    dateTimePicker1.Enabled = true;
                }
            }
            else
            {
                btnDone.Enabled = false;
                lblShownm.Text= String.Empty;
                lblShowservice.Text = String.Empty;
                lblShowusnm.Text= String.Empty;
                lblShowodrdate.Text= String.Empty;
                txtStatus.Text= String.Empty;
                lblShowcollectdate.Text= String.Empty;
                MessageBox.Show(stat);
            }
        }

        private void Completion_Load(object sender, EventArgs e)
        {
            btnDone.Enabled = false;
            txtDes.Enabled = false;
            txtStatus.Enabled = false;
            dateTimePicker1.Enabled = false;
        }
    }
}
