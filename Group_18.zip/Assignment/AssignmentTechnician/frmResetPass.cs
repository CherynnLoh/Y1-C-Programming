﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AssignmentTechnician
{
    public partial class frmResetPass : Form
    {
        public  string userName;
        public  string passWord;
        public frmResetPass()
        {
            InitializeComponent();
        }

        public frmResetPass(string usn,string pass)
        {
            InitializeComponent();
            userName = usn;
            passWord = pass;
            txtOldPass.Focus();
        }

        private void ResetTechPassword_Load(object sender, EventArgs e)
        {
 
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if ((txtOldPass.Text == "") || (txtNewPass.Text == "") || (txtConfirmPass.Text == ""))
            {
                MessageBox.Show("Caution!!\nPlease Enter password to all textbox!");
            }
            else
            {
                User obj = new User(userName, passWord);
                string status = (obj.updatePass(txtOldPass.Text, txtNewPass.Text, txtConfirmPass.Text));
                MessageBox.Show(status);
                if (status == "Update Successfully.")
                {
                    this.Close();
                }
                else
                {
                    txtConfirmPass.Text = string.Empty;
                    txtNewPass.Text = string.Empty;
                    txtOldPass.Text = string.Empty;
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
