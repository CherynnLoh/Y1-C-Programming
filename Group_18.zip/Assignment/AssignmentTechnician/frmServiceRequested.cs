﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AssignmentTechnician
{
    public partial class frmServiceRequested : Form
    {
        public frmServiceRequested()
        {
            InitializeComponent();
        }

        private void lblShow2_Click(object sender, EventArgs e)
        {

        }

        private void lblShow3_Click(object sender, EventArgs e)
        {

        }

        private void lblShow1_Click(object sender, EventArgs e)
        {

        }

        private void lblStatus_Click(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string stat;
            Service obj1= new Service(txtOrderID.Text);
            stat = obj1.checkOrderID(txtOrderID.Text);
            if (stat == null)
            {
                btnUpdate.Enabled = false;
                Service.viewService(obj1);
                lblUsername.Text = obj1.UserName;
                lblName.Text = obj1.FullName;
                lblCusService.Text = obj1.Cusservice;
                lblOrdDate.Text = obj1.Orderdate;
                lblAmount.Text = "RM"+obj1.Amount.ToString();
                txtStatus.Text = obj1.Status;
                if (txtStatus.Text != "Complete")
                {
                    btnEdit.Enabled = true;
                }
                else
                {
                    btnEdit.Enabled=false;
                }
                txtStatus.Enabled = false;
            }
            else
            {
                lblUsername.Text = String.Empty;
                lblName.Text = String.Empty;
                lblCusService.Text = String.Empty;
                lblOrdDate.Text= String.Empty;
                lblAmount.Text= String.Empty;
                txtStatus.Text = String.Empty;
                MessageBox.Show(stat);
                btnEdit.Enabled= false;
                btnUpdate.Enabled= false;
            }
        }

        private void ServiceRequested_Load(object sender, EventArgs e)
        {
            btnEdit.Enabled = false;
            btnUpdate.Enabled=false;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Enter Pending/Ongoing");
            txtStatus.Enabled = true;
            btnUpdate.Enabled = true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtStatus.Text == "Pending" || txtStatus.Text == "Ongoing")
            {
                Service obj1 = new Service(txtOrderID.Text.ToString());
                MessageBox.Show(obj1.updateStatus(txtStatus.Text));
                txtStatus.Enabled = false;
                btnEdit.Enabled = true;
                btnUpdate.Enabled = false;
            }
            else
            {
                Service obj1 = new Service(txtOrderID.Text.ToString());
                MessageBox.Show("Invalid Input in Service text box.Please try again.:)");
                Service.viewService(obj1);
                txtStatus.Text = obj1.Status;
                txtStatus.Enabled=false;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
