﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace AssignmentTechnician
{
    public partial class frmUpdateProfile : Form
    {
        public string userName;
        public string passWord;
        public string role;

        public frmUpdateProfile()
        {
            InitializeComponent();
        }

        public frmUpdateProfile(string usm)
        {
            InitializeComponent();
            userName = usm;
        }

        public frmUpdateProfile(string usm,string pass)
        {
            InitializeComponent();
            userName = usm;
            passWord = pass;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UpdateTech_Load(object sender, EventArgs e)
        {;
            User obj = new User(userName);
            role = obj.checkRole();
            if (role == "customer")
            {
                Customer obj1 = new Customer(userName);
                Customer.viewProfile(obj1);

                lblShowName.Text = obj1.CusfullName;
                lblshowUsernm.Text = userName;
                lblGender.Text = obj1.CusGender;
                txtEmail.Text = obj1.CusEmail;
                txtNum.Text = obj1.CusPhone;
            }
            else
            {
                Staff obj1 = new Staff(userName);
                Staff.viewProfile(obj1);

                lblShowName.Text = obj1.StaffFullName;
                lblshowUsernm.Text = obj1.StaffUsername;
                txtEmail.Text = obj1.StaffEmail;
                txtNum.Text = obj1.StaffcontactNum;
                lblGender.Text = obj1.Staffgender;
            }
     
        }

        private void btnEmail_Click(object sender, EventArgs e)
        {
            Regex emailformat = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = emailformat.Match(txtEmail.Text);
            if (role == "customer")
            {
                Customer obj = new Customer(userName);
                Customer.viewProfile(obj);
                if (txtEmail.Text == obj.CusEmail)
                {
                    MessageBox.Show("Nothing has changed");
                }
                else if ((match.Success) && (txtEmail.Text != obj.CusEmail))
                {
                    MessageBox.Show(obj.updateCusEmail(txtEmail.Text));
                }
                else
                {
                    MessageBox.Show("Invalid email format(xxx@xxx.xxx)");
                    txtEmail.Text = obj.CusEmail;
                }
            }
            else
            {
                Staff obj = new Staff(userName);
                Staff.viewProfile(obj);
                if (txtEmail.Text == obj.StaffEmail)
                {
                    MessageBox.Show("Nothing has changed");
                }
                else if ((match.Success) && (txtEmail.Text != obj.StaffEmail))
                {
                    MessageBox.Show(obj.updateStaffEmail(txtEmail.Text));
                }
                else
                {
                    MessageBox.Show("Invalid email format(xxx@xxx.xxx)");
                    txtEmail.Text = obj.StaffEmail;
                }
            }

        }

        private void btnNum_Click(object sender, EventArgs e)
        {
            Regex phoneformat = new Regex(@"^\(?([0-9]{3})\)?-([0-9]{7})$");
            Match match1 = phoneformat.Match(txtNum.Text);

            if (role == "customer")
            {
                Customer obj = new Customer(userName);
                Customer.viewProfile(obj);
                if (txtNum.Text == obj.CusPhone)
                {
                    MessageBox.Show("Nothing has changed");
                }
                else if ((match1.Success) && (txtNum.Text != obj.CusPhone))
                {
                    MessageBox.Show(obj.updateCusPhone(txtNum.Text));
                }
                else
                {
                    MessageBox.Show("Invalid Phone Format(xxx-xxxxxxx)");
                    txtNum.Text = obj.CusPhone;
                }
            }
            else
            {
                Staff obj = new Staff(userName);
                Staff.viewProfile(obj);
                if (txtNum.Text == obj.StaffcontactNum)
                {
                    MessageBox.Show("Nothing has changed");
                }
                else if ((match1.Success) && (txtNum.Text != obj.StaffcontactNum))
                {
                    MessageBox.Show(obj.updateStaffPhone(txtNum.Text));
                }
                else
                {
                    MessageBox.Show("Invalid Phone Format(xxx-xxxxxxx)");
                    txtNum.Text = obj.StaffcontactNum;
                }
            }

        }

        private void btnPassword_Click(object sender, EventArgs e)
        {
            frmResetPass obj2 = new frmResetPass(userName,passWord);
            obj2.ShowDialog();

        }

        private void lblGender_Click(object sender, EventArgs e)
        {

        }
    }
}
